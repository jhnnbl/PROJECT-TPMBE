<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;


class DataController extends Controller
{
    public function show(){
       $books = Book::all();
        return view('welcome', compact('books'));
    }

    public function create(){
        return view('CreateInput');
    }
  
    public function store(Request $request){
        Book::create([
            
            //nama atribut => $request -> name dari input form
            'Nama' => $request -> Nama,
            'NIM' => $request -> NIM,
            'NomorAbsen' => $request -> NomorAbsen,
            'EmailBinus' => $request -> EmailBinus
        ]);

        return redirect(route('show'));
    }    
}
